"use strict";
(() => {
var exports = {};
exports.id = 829;
exports.ids = [829];
exports.modules = {

/***/ 3919:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages_store),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./lib/commerce.js
var commerce = __webpack_require__(6744);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/Shop/Item.js





const Item = ({ products , addToCart  })=>{
    const { available  } = products.inventory;
    const { 0: addSuccess , 1: setAddSuccess  } = (0,external_react_.useState)(false);
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 6,
        sm: 4,
        md: 3,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Card, {
            sx: {
                maxWidth: 300,
                backgroundColor: '#F5F5F5',
                paddingX: 2,
                paddingY: 2,
                borderRadius: 4,
                margin: 1,
                borderColor: '#F5F5F5',
                position: 'relative'
            },
            variant: "outlined",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Card, {
                    sx: {
                        position: 'relative',
                        width: '100%',
                        height: '100%',
                        borderRadius: 6,
                        display: 'block'
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: '/productpage/' + products.permalink,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                src: products.media.source,
                                alt: products.name,
                                layout: "responsive",
                                // placeholder='blur'
                                // blurDataURL={products.media.source}
                                height: "10%",
                                width: "10%",
                                objectFit: "cover",
                                sizes: "50vw"
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.CardContent, {
                    align: "center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            variant: "h5",
                            component: "div",
                            noWrap: true,
                            children: products.name
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            variant: "h6",
                            children: products.price.formatted_with_symbol
                        }),
                        addSuccess ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                            variant: "contained",
                            sx: {
                                mx: 'auto'
                            },
                            disabled: true,
                            children: "Item Added!"
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                            variant: "contained",
                            sx: {
                                mx: 'auto'
                            },
                            disabled: available === 0,
                            onClick: ()=>addToCart(products.id).then(setAddSuccess(true))
                            ,
                            children: available === 0 ? 'Out of Stock' : 'Add To Cart'
                        })
                    ]
                })
            ]
        })
    }));
};
/* harmony default export */ const Shop_Item = (Item);

// EXTERNAL MODULE: external "@mui/system"
var system_ = __webpack_require__(7986);
;// CONCATENATED MODULE: ./components/Shop/ProductSection.js




const ProductSection = (props)=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        id: props.title,
        align: "center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(system_.Box, {
                sx: {
                    backgroundColor: '#052469',
                    color: '#FFF',
                    borderRadius: 4,
                    width: '50%'
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Typography, {
                    variant: "h5",
                    children: [
                        "~ ",
                        props.title,
                        " ~"
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                container: true,
                children: props.product.map((product)=>/*#__PURE__*/ jsx_runtime_.jsx(Shop_Item, {
                        products: product,
                        addToCart: props.addToCart
                    }, product.id)
                )
            })
        ]
    }));
};
/* harmony default export */ const Shop_ProductSection = (ProductSection);

// EXTERNAL MODULE: ./context/loadCartData.js
var loadCartData = __webpack_require__(8694);
;// CONCATENATED MODULE: ./pages/store.js






async function getStaticProps() {
    const { data: tops  } = await commerce/* default.products.list */.Z.products.list({
        category_slug: [
            'shirt'
        ],
        limit: 100
    });
    const { data: bottoms  } = await commerce/* default.products.list */.Z.products.list({
        category_slug: [
            'pants' || 0
        ],
        limit: 100
    });
    const { data: hats  } = await commerce/* default.products.list */.Z.products.list({
        category_slug: [
            'hat'
        ],
        limit: 100
    });
    const { data: games  } = await commerce/* default.products.list */.Z.products.list({
        category_slug: [
            'video-game'
        ],
        limit: 100
    });
    return {
        props: {
            tops,
            bottoms,
            hats,
            games
        }
    };
}
;
const store = (props)=>{
    const { setCart  } = (0,loadCartData/* CartDispatch */.Dk)();
    const addToCart = async (productID)=>{
        const { cart  } = await commerce/* default.cart.add */.Z.cart.add(productID);
        setCart(cart);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx("title", {
                    children: "Shop"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
                sx: {
                    paddingY: 5
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        align: "center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            variant: "h2",
                            gutterBottom: true,
                            children: "Shop"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        container: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Shop_ProductSection, {
                            product: props.tops,
                            title: "Shirts",
                            addToCart: addToCart
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        container: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Shop_ProductSection, {
                            product: props.bottoms,
                            title: "Bottoms",
                            addToCart: addToCart
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        container: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Shop_ProductSection, {
                            product: props.hats,
                            title: "Hats",
                            addToCart: addToCart
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                        container: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Shop_ProductSection, {
                            product: props.games,
                            title: "Video Games",
                            addToCart: addToCart
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const pages_store = (store);


/***/ }),

/***/ 6423:
/***/ ((module) => {

module.exports = require("@chec/commerce.js");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 7986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,675,744,694], () => (__webpack_exec__(3919)));
module.exports = __webpack_exports__;

})();