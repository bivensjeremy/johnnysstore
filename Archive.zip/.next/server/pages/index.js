(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 1288:
/***/ ((module) => {

// Exports
module.exports = {
	"background": "Home_background__I_nYJ",
	"main": "Home_main__nLjiQ",
	"dotted": "Home_dotted__wveNg",
	"center": "Home_center__4BFgC"
};


/***/ }),

/***/ 6686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/Landing Page/Category.js



function Category({ image , title  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Card, {
        sx: {
            maxWidth: 350,
            backgroundColor: '#b9d4e4',
            padding: 3,
            borderRadius: 4
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.CardMedia, {
                component: "img",
                image: image,
                alt: title + ' img',
                sx: {
                    borderRadius: 6,
                    height: 200,
                    objectFit: 'contain'
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.CardContent, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        variant: "h5",
                        component: "div",
                        align: "center",
                        gutterBottom: true,
                        children: title
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                        href: '/store#' + title,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Button, {
                                variant: "contained",
                                children: [
                                    "Shop ",
                                    title
                                ]
                            })
                        })
                    })
                ]
            })
        ]
    }));
};

;// CONCATENATED MODULE: external "@mui/material/Grid"
const Grid_namespaceObject = require("@mui/material/Grid");
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid_namespaceObject);
;// CONCATENATED MODULE: external "@mui/material/Container"
const Container_namespaceObject = require("@mui/material/Container");
var Container_default = /*#__PURE__*/__webpack_require__.n(Container_namespaceObject);
// EXTERNAL MODULE: ./styles/Home.module.css
var Home_module = __webpack_require__(1288);
var Home_module_default = /*#__PURE__*/__webpack_require__.n(Home_module);
;// CONCATENATED MODULE: ./components/Landing Page/Categories.js





const Categories = ()=>{
    const shirts = {
        image: '/tshirt.svg',
        title: 'Shirts'
    };
    const bottoms = {
        image: '/pants.svg',
        title: 'Bottoms'
    };
    const hats = {
        image: '/hat.png',
        title: 'Hats'
    };
    const games = {
        image: '/game.png',
        title: 'Games'
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        align: "center",
        className: (Home_module_default()).background,
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Grid_default()), {
                container: true,
                spacing: 10,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        xs: 12,
                        md: 3,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Category, {
                            ...shirts
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        xs: 12,
                        md: 3,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Category, {
                            ...bottoms
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        xs: 12,
                        md: 3,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Category, {
                            ...hats
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                        item: true,
                        xs: 12,
                        md: 3,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Category, {
                            ...games
                        })
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const Landing_Page_Categories = (Categories);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/Landing Page/FeaturedItem.js



const FeaturedItem = ({ products  })=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Card, {
        raised: false,
        sx: {
            maxWidth: 370,
            backgroundColor: '#F5F5F5',
            padding: 3,
            borderRadius: 4
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Card, {
                sx: {
                    position: 'relative',
                    width: '100%',
                    height: '100%',
                    borderRadius: 6,
                    display: 'block'
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                    src: products.media.source,
                    alt: "Featured Product Image",
                    layout: "responsive",
                    placeholder: "blur",
                    blurDataURL: products.media.source,
                    height: 70,
                    width: "100%",
                    objectFit: "cover",
                    sizes: "10vw"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.CardContent, {
                align: "center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        variant: "h5",
                        component: "div",
                        fontWeight: 700,
                        children: products.name
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                        variant: "h6",
                        component: "div",
                        children: products.price.formatted_with_symbol
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.CardActions, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        margin: 'auto'
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Link, {
                        href: '/productpage/' + products.permalink,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                            variant: "contained",
                            size: "large",
                            sx: {
                                mx: 'auto'
                            },
                            children: "View Item"
                        })
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const Landing_Page_FeaturedItem = (FeaturedItem);

;// CONCATENATED MODULE: ./components/Landing Page/FeaturedSection.js



const FeaturedSection = ({ products  })=>{
    const rand = Math.floor(Math.random() * products.length);
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        align: "center",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
            sx: {
                paddingBottom: 10
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                    variant: "h3",
                    component: "div",
                    gutterBottom: true,
                    children: "Featured Item"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Landing_Page_FeaturedItem, {
                    products: products[rand]
                })
            ]
        })
    }));
};
/* harmony default export */ const Landing_Page_FeaturedSection = (FeaturedSection);

;// CONCATENATED MODULE: ./components/Landing Page/SplashPage.js





const SplashPage = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Home_module_default()).main,
        align: "center",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            children: "Welcome to"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            sx: {
                                fontFamily: 'Sacramento'
                            },
                            variant: "h1",
                            children: "Johnny's"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/store",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                    variant: "contained",
                                    size: "large",
                                    sx: {
                                        margin: 2,
                                        cursor: 'pointer'
                                    },
                                    children: "Store"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                            children: "Best high end threads... or something like that"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                src: "/citybackground.png",
                alt: "City Background",
                layout: "intrinsic",
                width: 1947,
                height: 518,
                priority: true
            })
        ]
    }));
};
/* harmony default export */ const Landing_Page_SplashPage = (SplashPage);

;// CONCATENATED MODULE: ./components/Landing Page/TaglineSection.js


const TaglineSection = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
        sx: {
            padding: 10
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                variant: "h2",
                align: "center",
                sx: {
                    fontFamily: 'Sacramento'
                },
                children: "Best in Fashion!"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    mx: 'auto',
                    width: '15%',
                    border: 'none',
                    borderTop: '5px dotted',
                    marginY: 2
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                sx: {
                    width: {
                        sm: '100%',
                        md: '50%'
                    },
                    mx: 'auto'
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                    variant: "body1",
                    align: "center",
                    children: "Hop in the time machine & shop the finest clothing on the internet! Yes, its a bunch of junk, but so what?!"
                })
            })
        ]
    }));
};
/* harmony default export */ const Landing_Page_TaglineSection = (TaglineSection);

;// CONCATENATED MODULE: ./components/Landing Page/AboutProjectSection.js

const AboutProjectSection = ()=>{
    return(/*#__PURE__*/ _jsx("div", {
        children: "About Project https://youtu.be/-FejFx44PyM"
    }));
};
/* harmony default export */ const Landing_Page_AboutProjectSection = ((/* unused pure expression or super */ null && (AboutProjectSection)));

;// CONCATENATED MODULE: ./components/Landing Page/KeyItemsCard.js


const KeyItemsCard = (keyItems)=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 6,
        md: 3,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Paper, {
            elevation: 0,
            align: "center",
            sx: {
                maxWidth: 345,
                padding: 4,
                backgroundColor: '#F5F5F5'
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                    sx: {
                        color: '#F05454'
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        className: "material-icons",
                        style: {
                            fontSize: 48 + 'px'
                        },
                        children: keyItems.image
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                    color: "inherit",
                    fontWeight: 700,
                    variant: "h5",
                    children: keyItems.name
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                    color: "inherit",
                    variant: "body1",
                    children: keyItems.description
                })
            ]
        })
    }));
};
/* harmony default export */ const Landing_Page_KeyItemsCard = (KeyItemsCard);

;// CONCATENATED MODULE: ./data/keyitems.js
const keyitems = [
    {
        id: 1,
        name: 'Standard Shipping',
        image: 'local_shipping',
        description: 'Probably ships UPS, but I may surprise you and ship USPS or FedEx'
    },
    {
        id: 2,
        name: 'No Returns',
        image: 'block',
        description: 'Why do you need to return it? Keep it, toss it, but you cannot send it back!'
    },
    {
        id: 3,
        name: 'Satisfaction Likely',
        image: 'gpp_good',
        description: 'The clothes dont suck, so you will likely appreciate them'
    },
    {
        id: 4,
        name: 'Support: Average',
        image: 'support_agent',
        description: 'Support available via email. Quick responses to address any needs!'
    }
];

;// CONCATENATED MODULE: ./components/Landing Page/KeyItemsSection.js




function createKeyItemsCard(keyItems) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(Landing_Page_KeyItemsCard, {
        name: keyItems.name,
        image: keyItems.image,
        description: keyItems.description
    }, keyItems.id));
}
const KeyItemsSection = ()=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        align: "center",
        children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                container: true,
                children: keyitems.map(createKeyItemsCard)
            })
        })
    }));
};
/* harmony default export */ const Landing_Page_KeyItemsSection = (KeyItemsSection);

// EXTERNAL MODULE: ./lib/commerce.js
var commerce = __webpack_require__(6744);
;// CONCATENATED MODULE: ./pages/index.js










async function getStaticProps() {
    const { data: products  } = await commerce/* default.products.list */.Z.products.list({
        limit: 100
    });
    return {
        props: {
            products
        }
    };
}
;
function Home({ products  }) {
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (Home_module_default()).container,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                    children: [
                        "Johnny",
                        `'`,
                        "s | for Bivens Blueprint, LLC."
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Landing_Page_SplashPage, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Landing_Page_Categories, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Landing_Page_TaglineSection, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Landing_Page_FeaturedSection, {
                        products: products
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Landing_Page_KeyItemsSection, {
                    })
                ]
            })
        ]
    }));
};


/***/ }),

/***/ 6423:
/***/ ((module) => {

"use strict";
module.exports = require("@chec/commerce.js");

/***/ }),

/***/ 5692:
/***/ ((module) => {

"use strict";
module.exports = require("@mui/material");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,675,744], () => (__webpack_exec__(6686)));
module.exports = __webpack_exports__;

})();