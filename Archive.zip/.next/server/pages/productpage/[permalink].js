"use strict";
(() => {
var exports = {};
exports.id = 408;
exports.ids = [408];
exports.modules = {

/***/ 2190:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _permalink_),
  "getStaticPaths": () => (/* binding */ getStaticPaths),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./lib/commerce.js
var commerce = __webpack_require__(6744);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/Shop/RelatedItems.js




const RelatedItems = ({ products  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
        item: true,
        xs: 12,
        sm: 3,
        marginX: "auto",
        padding: 3,
        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
            href: '/productpage/' + products.permalink,
            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Card, {
                    raised: false,
                    sx: {
                        maxWidth: 250,
                        backgroundColor: '#F5F5F5',
                        padding: 2,
                        borderRadius: 4
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(material_.Card, {
                            sx: {
                                position: 'relative',
                                width: '100%',
                                height: '100%',
                                borderRadius: 6,
                                display: 'block'
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                src: products.media.source,
                                alt: products.name,
                                layout: "responsive",
                                placeholder: "blur",
                                blurDataURL: products.media.source,
                                height: "100%",
                                width: "100%",
                                objectFit: "cover",
                                sizes: "50vw"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.CardContent, {
                            align: "center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    variant: "h6",
                                    children: products.name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    variant: "subtitle1",
                                    children: products.price.formatted_with_symbol
                                })
                            ]
                        })
                    ]
                })
            })
        })
    }));
};
/* harmony default export */ const Shop_RelatedItems = (RelatedItems);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./context/loadCartData.js
var loadCartData = __webpack_require__(8694);
;// CONCATENATED MODULE: ./pages/productpage/[permalink].js








async function getStaticProps({ params  }) {
    const { permalink  } = params;
    const product = await commerce/* default.products.retrieve */.Z.products.retrieve(permalink, {
        type: 'permalink'
    });
    return {
        props: {
            product
        }
    };
}
async function getStaticPaths() {
    const { data: products  } = await commerce/* default.products.list */.Z.products.list({
        limit: 200
    });
    return {
        paths: products.map((product)=>({
                params: {
                    permalink: product.permalink
                }
            })
        ),
        fallback: false
    };
}
function createRelatedProductCard(product, { addToCart  }) {
    return(/*#__PURE__*/ jsx_runtime_.jsx(Shop_RelatedItems, {
        products: product,
        addToCart: addToCart
    }, product.id));
}
;
const ProductPage = ({ product  })=>{
    const { 0: addSuccess , 1: setAddSuccess  } = (0,external_react_.useState)(false);
    const { setCart  } = (0,loadCartData/* CartDispatch */.Dk)();
    const { available  } = product.inventory;
    const [anchorEl, setAnchorEl] = external_react_default().useState(null);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    const open = Boolean(anchorEl);
    const id = open ? 'simple-popover' : undefined;
    const addToCart = async (productID)=>{
        const { cart  } = await commerce/* default.cart.add */.Z.cart.add(productID);
        setCart(cart);
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                        children: [
                            "Johnny's | ",
                            product.name
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "apple-touch-icon",
                        sizes: "180x180",
                        href: "images/apple-touch-icon.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        type: "image/png",
                        sizes: "32x32",
                        href: "images/favicon-32x32.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        type: "image/png",
                        sizes: "16x16",
                        href: "images/favicon-16x16.png"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "manifest",
                        href: "images/site.webmanifest"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "images/favicon.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(material_.Container, {
                sx: {
                    paddingY: 5
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                    container: true,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                            item: true,
                            xs: 12,
                            md: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    align: "center",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Card, {
                                        sx: {
                                            backgroundColor: '#F5F5F5',
                                            borderColor: '#F5F5F5',
                                            paddingX: 2,
                                            paddingY: 2,
                                            borderRadius: 4,
                                            margin: 5,
                                            position: 'relative'
                                        },
                                        variant: "outlined",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Card, {
                                                sx: {
                                                    position: 'relative',
                                                    width: '100%',
                                                    height: '100%',
                                                    borderRadius: 3,
                                                    display: 'block'
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                                    src: product.media.source,
                                                    alt: product.name,
                                                    layout: "responsive",
                                                    height: "50%",
                                                    width: "50%",
                                                    objectFit: "cover",
                                                    placeholder: "blur",
                                                    blurDataURL: product.media.source,
                                                    onClick: handleClick,
                                                    priority: true,
                                                    sizes: "50vw"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(material_.Box, {
                                                sx: {
                                                    fontStyle: 'italic'
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                                    children: "Click image to enlarge"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Popover, {
                                    id: id,
                                    open: open,
                                    anchorEl: anchorEl,
                                    onClose: handleClose,
                                    anchorOrigin: {
                                        vertical: 'top',
                                        horizontal: 'top'
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_image["default"], {
                                        src: product.media.source,
                                        alt: product.name,
                                        layout: "intrinsic",
                                        height: 800,
                                        width: 700
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Grid, {
                            item: true,
                            xs: 12,
                            md: 6,
                            marginY: "auto",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    variant: "h2",
                                    children: product.name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    variant: "h6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        dangerouslySetInnerHTML: {
                                            __html: product.description
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    variant: "h4",
                                    fontWeight: 700,
                                    gutterBottom: true,
                                    children: product.price.formatted_with_symbol
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    align: "left",
                                    children: addSuccess ? /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                        variant: "contained",
                                        size: "large",
                                        sx: {
                                            mx: 'auto'
                                        },
                                        disabled: true,
                                        children: "Item Added!"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(material_.Button, {
                                        variant: "contained",
                                        size: "large",
                                        sx: {
                                            mx: 'auto'
                                        },
                                        disabled: available === 0,
                                        onClick: ()=>addToCart(product.id).then(setAddSuccess(true))
                                        ,
                                        children: available === 0 ? 'Out of Stock' : 'Add To Cart'
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(material_.Container, {
                            align: "center",
                            sx: {
                                paddingY: 5
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Typography, {
                                    variant: "h5",
                                    fontWeight: 700,
                                    children: "Check out these other items"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(material_.Grid, {
                                    container: true,
                                    children: product.related_products.map(createRelatedProductCard)
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const _permalink_ = (ProductPage);


/***/ }),

/***/ 6423:
/***/ ((module) => {

module.exports = require("@chec/commerce.js");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 8028:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3018:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,664,675,744,694], () => (__webpack_exec__(2190)));
module.exports = __webpack_exports__;

})();