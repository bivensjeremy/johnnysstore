"use strict";
(() => {
var exports = {};
exports.id = 882;
exports.ids = [882];
exports.modules = {

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 5237:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
function handler(req, res) {
    const HOST = "bivensblueprint.com";
    const PASS = "contactpassword";
    const USER = "contact@bivensblueprint.com";
    const nodemailer = __webpack_require__(5184);
    const smtpTrans = nodemailer.createTransport({
        host: HOST,
        port: 465,
        secure: true,
        auth: {
            user: USER,
            pass: PASS
        }
    });
    const mailOpts = {
        from: 'contact@bivensblueprint.com',
        replyTo: `${req.body.email}`,
        to: 'admin@bivensblueprint.com',
        subject: 'Johnny`s | Contact Support',
        html: `
                <h4><b>Name:</b></h4> ${req.body.name} <br>  
                <h4><b>Email:</b></h4> ${req.body.email} <br> 
                <h4><b>Message:</b></h4> ${req.body.message}
                `
    };
    smtpTrans.sendMail(mailOpts, function(err, success) {
        if (err) {
            res.json({
                status: 'fail'
            });
            console.log(err);
        } else {
            res.json({
                status: 'success'
            });
            console.log('message sent');
        }
    });
};
;


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5237));
module.exports = __webpack_exports__;

})();