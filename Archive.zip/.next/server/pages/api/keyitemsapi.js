"use strict";
(() => {
var exports = {};
exports.id = 819;
exports.ids = [819];
exports.modules = {

/***/ 1031:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: ./data/keyitems.js
const keyitems = [
    {
        id: 1,
        name: 'Standard Shipping',
        image: 'local_shipping',
        description: 'Probably ships UPS, but I may surprise you and ship USPS or FedEx'
    },
    {
        id: 2,
        name: 'No Returns',
        image: 'block',
        description: 'Why do you need to return it? Keep it, toss it, but you cannot send it back!'
    },
    {
        id: 3,
        name: 'Satisfaction Likely',
        image: 'gpp_good',
        description: 'The clothes dont suck, so you will likely appreciate them'
    },
    {
        id: 4,
        name: 'Support: Average',
        image: 'support_agent',
        description: 'Support available via email. Quick responses to address any needs!'
    }
];

;// CONCATENATED MODULE: ./pages/api/keyitemsapi.js

function handler(req, res) {
    res.status(200).json(keyitems);
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1031));
module.exports = __webpack_exports__;

})();