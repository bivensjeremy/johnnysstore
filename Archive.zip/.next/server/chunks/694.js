"use strict";
exports.id = 694;
exports.ids = [694];
exports.modules = {

/***/ 8694:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Zl": () => (/* binding */ CartProvider),
/* harmony export */   "xI": () => (/* binding */ CartState),
/* harmony export */   "Dk": () => (/* binding */ CartDispatch)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_commerce__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6744);



const CartStateContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const CartDispatchContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const SET_CART = 'SET_CART';
const initialState = {
    total_items: 0,
    total_unique_items: 0,
    line_items: [],
    subtotal: {
        raw: 100
    }
};
const reducer = (state, action)=>{
    switch(action.type){
        case SET_CART:
            return {
                ...state,
                ...action.payload
            };
        default:
            throw new Error(`Unknown action: ${action.type}`);
    }
};
const CartProvider = ({ children  })=>{
    const { 0: state , 1: dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, initialState);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        getCart();
    }, []);
    const setCart = (payload)=>dispatch({
            type: SET_CART,
            payload
        })
    ;
    const getCart = async ()=>{
        try {
            const cart = await _lib_commerce__WEBPACK_IMPORTED_MODULE_2__/* ["default"].cart.retrieve */ .Z.cart.retrieve();
            setCart(cart);
        } catch (err) {
            console.log(err);
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartDispatchContext.Provider, {
        value: {
            setCart
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CartStateContext.Provider, {
            value: state,
            children: children
        })
    }));
};
const CartState = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(CartStateContext)
;
const CartDispatch = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(CartDispatchContext)
;


/***/ })

};
;