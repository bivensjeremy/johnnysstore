const Donate = () => {
    return (
        <div>
            Donate to the cause!
        </div>
    );
}

export default Donate;