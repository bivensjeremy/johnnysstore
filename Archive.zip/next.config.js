
module.exports = {
  images: {
    domains: ['cdn.chec.io']
  },
  reactStrictMode: true,
};
